

counter=0

while [ $counter -le 100 ]
do
	echo "hello"
	counter=`expr $counter + 1`
done

